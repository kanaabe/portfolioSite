<em><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<link rel="stylesheet" type="text/css" href="css/style.css">


<!--
<div class="iframe-link-2">  
<iframe class ="iframeautowidth-2" src="about.php" frameBorder= "0" name="iframe-2"></iframe>
</div> 
-->
<div class="iframe-link">  
<iframe class ="iframeautowidth" frameBorder= "0" name="iframe" src="about.php"></iframe>
</div>   

<nav>
  <div class="menu-item alpha">
    <h4><a href="about.php" target="iframe">KANA ABE</a></h4>
      <p>e:kanakoabe5@gmail.com</p>
      <p>p:9738000884</p>
      <p>t:@kana_abe</p>
  </div>
 
    <div class="menu-item" id="menu-item-4">
    <h4><a href="#">ART</a></h4>
    <ul>
      <li><a href="drawing.php" target="iframe">Drawing</a></li>
      <li><a href="design.php" target="iframe">Creative Editorial</a></li>
      <li><a href="installation.php" target="iframe">Arduino/Processing</a></li>
      <!--<li><a href="video.php" target="iframe">Video</a></li>-->
      <li><a href="photography.php" target="iframe">Photography</a></li>
     <!-- <li><a href="print.php" target="iframe">Screen Print</a></li> -->
    </ul>
  </div>
  
  <div class="menu-item" id="menu-item-1">
    <h4><a href="#">SCIENCE</a></h4>
    <ul>
      <!--<li><a href="iciap.pdf" target="_tab">Research</a></li>-->
      <li><a href="research.php" target="iframe">Research</a></li>
    </ul>
  </div>
  
   <div class="menu-item" id="menu-item-1">
    <h4><a href="#">RESUME</a></h4>
    <ul>
      <li><a href="resume.pdf" target="_blank">PDF</a></li>
    </ul>
  </div>
    </nav>
   <!-- COMING SOON
  <div class="menu-item" id="menu-item-2">
    <h4><a href="about">BLOG</a></h4>
  </div>
    -->
  
</body>

</html>
